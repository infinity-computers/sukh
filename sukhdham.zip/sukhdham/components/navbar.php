<header>
    <div class="container nav-container">
        <div class="logo">
            <img src="/images/logo.svg" alt="Sukhdham Estate Agency" class="logo-img">
            Sukhdham Estate Agency
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="/index.html">Home</a></li>
                <li><a href="/properties.php">Properties</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#testimonials">Testimonials</a></li>
                <li><a href="#contact">Contact</a></li>
                <?php if (isset($_SESSION['admin_id'])): ?>
                    <li><a href="/admin/dashboard.php">Dashboard</a></li>
                    <li><a href="/admin/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="/admin/index.php">Admin</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="menu-toggle">&#9776;</div>
    </div>
</header>