<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/index.php');
    exit;
}

$current_time = time();
$last_activity = $_SESSION['last_activity'] ?? $current_time;
$timeout = SESSION_TIMEOUT_MINUTES * 60;

if ($current_time - $last_activity > $timeout) {
    session_destroy();
    header('Location: /admin/index.php');
    exit;
}

$_SESSION['last_activity'] = $current_time;

require_once __DIR__ . '/../config/database.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$admin_id = $_SESSION['admin_id'];
$property_id = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM properties WHERE id = ? AND admin_id = ?");
$stmt->bind_param('ii', $property_id, $admin_id);
$stmt->execute();
$property = $stmt->get_result()->fetch_assoc();

if (!$property) {
    header('Location: /admin/dashboard.php');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM property_images WHERE property_id = ?");
$stmt->bind_param('i', $property_id);
$stmt->execute();
$images = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $price = !empty($_POST['price']) ? floatval($_POST['price']) : null;
    $bedrooms = intval($_POST['bedrooms'] ?? 0);
    $bathrooms = intval($_POST['bathrooms'] ?? 0);
    $area_sqft = intval($_POST['area_sqft'] ?? 0);
    
    if (empty($title)) {
        $error = 'Title is required';
    } elseif (empty($address)) {
        $error = 'Address is required';
    } else {
        $stmt = $conn->prepare("UPDATE properties SET title = ?, description = ?, address = ?, price = ?, bedrooms = ?, bathrooms = ?, area_sqft = ? WHERE id = ?");
        $stmt->bind_param('sssdiisi', $title, $description, $address, $price, $bedrooms, $bathrooms, $area_sqft, $property_id);
        
        if ($stmt->execute()) {
            if (isset($_FILES['images']) && is_array($_FILES['images']['tmp_name'])) {
                $current_image_count = count($images);
                $image_count = count($_FILES['images']['tmp_name']);
                
                for ($i = 0; $i < $image_count; $i++) {
                    if ($_FILES['images']['error'][$i] === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }
                    
                    if ($current_image_count >= MAX_IMAGES_PER_PROPERTY) {
                        break;
                    }
                    
                    $file = [
                        'name' => $_FILES['images']['name'][$i],
                        'tmp_name' => $_FILES['images']['tmp_name'][$i],
                        'error' => $_FILES['images']['error'][$i],
                        'size' => $_FILES['images']['size'][$i]
                    ];
                    
                    $validation = validateImage($file);
                    if (!$validation['valid']) {
                        continue;
                    }
                    
                    $result = saveImage($file, $property_id);
                    if ($result['success']) {
                        $stmt = $conn->prepare("INSERT INTO property_images (property_id, image_url, is_primary) VALUES (?, ?, FALSE)");
                        $stmt->bind_param('is', $property_id, $result['url']);
                        $stmt->execute();
                        $current_image_count++;
                    }
                }
            }
            
            header('Location: /admin/dashboard.php');
            exit;
        } else {
            $error = 'Failed to update property';
        }
    }
}

function validateImage($file) {
    $errors = [];
    
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'errors' => ['File upload failed']];
    }
    
    if ($file['size'] > MAX_IMAGE_SIZE) {
        $errors[] = "File size exceeds limit";
    }
    
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_ext, ALLOWED_IMAGE_TYPES)) {
        $errors[] = "Invalid file type";
    }
    
    $image_info = getimagesize($file['tmp_name']);
    if (!$image_info) {
        $errors[] = "Unable to read image";
    } else {
        $width = $image_info[0];
        $height = $image_info[1];
        
        if ($width < MIN_IMAGE_WIDTH || $height < MIN_IMAGE_HEIGHT) {
            $errors[] = "Image must be at least " . MIN_IMAGE_WIDTH . "x" . MIN_IMAGE_HEIGHT . "px";
        }
    }
    
    return ['valid' => count($errors) === 0, 'errors' => $errors];
}

function saveImage($file, $property_id) {
    $timestamp = time();
    $random = rand(1000, 9999);
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = "property_{$property_id}_{$timestamp}_{$random}.{$file_ext}";
    
    $filepath = UPLOAD_DIR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false];
    }
    
    $image_url = UPLOAD_URL . $filename;
    return ['success' => true, 'url' => $image_url];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Property - Sukhdham</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/components/navbar.php'; ?>
    
    <div class="max-w-3xl mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Edit Property</h1>
            <a href="/admin/dashboard.php" class="text-blue-600 hover:text-blue-800">← Back to Dashboard</a>
        </div>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" class="bg-white rounded-lg shadow p-6">
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Title *</label>
                <input type="text" name="title" required 
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       value="<?php echo htmlspecialchars($property['title']); ?>">
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Description</label>
                <textarea name="description" rows="4" 
                          class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($property['description'] ?? ''); ?></textarea>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Address *</label>
                <input type="text" name="address" required 
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       value="<?php echo htmlspecialchars($property['address']); ?>">
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Price (₹)</label>
                    <input type="number" name="price" step="0.01" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           value="<?php echo htmlspecialchars($property['price'] ?? ''); ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Area (Sq.ft)</label>
                    <input type="number" name="area_sqft" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           value="<?php echo htmlspecialchars($property['area_sqft'] ?? ''); ?>">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Bedrooms</label>
                    <input type="number" name="bedrooms" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           value="<?php echo htmlspecialchars($property['bedrooms'] ?? ''); ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Bathrooms</label>
                    <input type="number" name="bathrooms" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           value="<?php echo htmlspecialchars($property['bathrooms'] ?? ''); ?>">
                </div>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Current Images (<?php echo count($images); ?>/10)</label>
                <?php if (!empty($images)): ?>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <?php foreach ($images as $img): ?>
                            <div class="relative border rounded-lg p-2">
                                <img src="<?php echo htmlspecialchars($img['image_url']); ?>" 
                                     class="w-full h-32 object-cover rounded">
                                <?php if ($img['is_primary']): ?>
                                    <span class="absolute top-1 left-1 bg-blue-600 text-white text-xs px-2 py-1 rounded">Primary</span>
                                <?php endif; ?>
                                <div class="flex gap-1 mt-2">
                                    <button type="button" onclick="setPrimary(<?php echo $img['id']; ?>)" 
                                            class="text-xs bg-gray-200 px-2 py-1 rounded hover:bg-gray-300">
                                        Set Primary
                                    </button>
                                    <button type="button" onclick="deleteImage(<?php echo $img['id']; ?>)" 
                                            class="text-xs bg-red-100 text-red-600 px-2 py-1 rounded hover:bg-red-200">
                                        Delete
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500">No images uploaded yet.</p>
                <?php endif; ?>
            </div>
            
            <?php if (count($images) < MAX_IMAGES_PER_PROPERTY): ?>
                <div class="mb-6">
                    <label class="block text-gray-700 font-medium mb-2">Add More Images</label>
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <input type="file" name="images[]" multiple accept="image/*" class="w-full">
                        <p class="text-gray-500 text-sm mt-2">Minimum 800x600px, Max 5MB per image (<?php echo MAX_IMAGES_PER_PROPERTY - count($images); ?> remaining)</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="flex gap-4">
                <button type="submit" 
                        class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Update Property
                </button>
                <a href="/admin/dashboard.php" 
                   class="bg-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-400">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    
    <script>
        function setPrimary(imageId) {
            fetch('/admin/edit.php?id=<?php echo $property_id; ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'action=set_primary&image_id=' + imageId
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert(data.message);
                }
            });
        }
        
        function deleteImage(imageId) {
            if (!confirm('Are you sure you want to delete this image?')) return;
            
            fetch('/admin/edit.php?id=<?php echo $property_id; ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'action=delete_image&image_id=' + imageId
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert(data.message);
                }
            });
        }
    </script>
    
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        header('Content-Type: application/json');
        
        if ($_POST['action'] === 'set_primary') {
            $image_id = intval($_POST['image_id'] ?? 0);
            
            $stmt = $conn->prepare("SELECT * FROM property_images WHERE id = ? AND property_id = ?");
            $stmt->bind_param('ii', $image_id, $property_id);
            $stmt->execute();
            $image = $stmt->get_result()->fetch_assoc();
            
            if (!$image) {
                echo json_encode(['success' => false, 'message' => 'Image not found']);
                exit;
            }
            
            $conn->query("UPDATE property_images SET is_primary = FALSE WHERE property_id = $property_id");
            $stmt = $conn->prepare("UPDATE property_images SET is_primary = TRUE WHERE id = ?");
            $stmt->bind_param('i', $image_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Primary image updated']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update']);
            }
            exit;
        }
        
        if ($_POST['action'] === 'delete_image') {
            $image_id = intval($_POST['image_id'] ?? 0);
            
            $stmt = $conn->prepare("SELECT * FROM property_images WHERE id = ? AND property_id = ?");
            $stmt->bind_param('ii', $image_id, $property_id);
            $stmt->execute();
            $image = $stmt->get_result()->fetch_assoc();
            
            if (!$image) {
                echo json_encode(['success' => false, 'message' => 'Image not found']);
                exit;
            }
            
            $filepath = str_replace(UPLOAD_URL, UPLOAD_DIR, $image['image_url']);
            if (file_exists($filepath)) {
                unlink($filepath);
            }
            
            $stmt = $conn->prepare("DELETE FROM property_images WHERE id = ?");
            $stmt->bind_param('i', $image_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Image deleted']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete']);
            }
            exit;
        }
    }
    
    $conn->close();
    ?>
</body>
</html>