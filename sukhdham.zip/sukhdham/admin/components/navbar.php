<nav class="bg-white shadow-md">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between items-center h-16">
            <div class="flex items-center">
                <a href="/admin/dashboard.php" class="text-2xl font-bold text-blue-600">
                    Sukhdham Admin
                </a>
            </div>
            <div class="hidden md:flex space-x-6">
                <a href="/admin/dashboard.php" class="text-gray-700 hover:text-blue-600">Dashboard</a>
                <a href="/admin/create.php" class="text-gray-700 hover:text-blue-600">Add Property</a>
                <a href="/index.html" class="text-gray-700 hover:text-blue-600">View Site</a>
                <a href="/admin/logout.php" class="text-gray-700 hover:text-red-600">Logout</a>
            </div>
        </div>
    </div>
</nav>