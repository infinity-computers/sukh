<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /admin/index.php');
    exit;
}

$current_time = time();
$last_activity = $_SESSION['last_activity'] ?? $current_time;
$timeout = SESSION_TIMEOUT_MINUTES * 60;

if ($current_time - $last_activity > $timeout) {
    session_destroy();
    header('Location: /admin/index.php');
    exit;
}

$_SESSION['last_activity'] = $current_time;

require_once __DIR__ . '/../config/database.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $price = !empty($_POST['price']) ? floatval($_POST['price']) : null;
    $bedrooms = intval($_POST['bedrooms'] ?? 0);
    $bathrooms = intval($_POST['bathrooms'] ?? 0);
    $area_sqft = intval($_POST['area_sqft'] ?? 0);
    
    if (empty($title)) {
        $error = 'Title is required';
    } elseif (empty($address)) {
        $error = 'Address is required';
    } else {
        $admin_id = $_SESSION['admin_id'];
        
        $stmt = $conn->prepare("INSERT INTO properties (admin_id, title, description, address, price, bedrooms, bathrooms, area_sqft, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param('isssdiis', $admin_id, $title, $description, $address, $price, $bedrooms, $bathrooms, $area_sqft);
        
        if ($stmt->execute()) {
            $property_id = $conn->insert_id;
            
            if (isset($_FILES['images']) && is_array($_FILES['images']['tmp_name'])) {
                $image_count = count($_FILES['images']['tmp_name']);
                $primary_set = false;
                
                for ($i = 0; $i < $image_count; $i++) {
                    if ($_FILES['images']['error'][$i] === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }
                    
                    $file = [
                        'name' => $_FILES['images']['name'][$i],
                        'tmp_name' => $_FILES['images']['tmp_name'][$i],
                        'error' => $_FILES['images']['error'][$i],
                        'size' => $_FILES['images']['size'][$i]
                    ];
                    
                    $validation = validateImage($file);
                    if (!$validation['valid']) {
                        continue;
                    }
                    
                    $result = saveImage($file, $property_id);
                    if ($result['success']) {
                        $is_primary = !$primary_set && isset($_POST['primary_image']) && $_POST['primary_image'] == $i;
                        $stmt = $conn->prepare("INSERT INTO property_images (property_id, image_url, is_primary) VALUES (?, ?, ?)");
                        $stmt->bind_param('isi', $property_id, $result['url'], $is_primary);
                        $stmt->execute();
                        
                        if ($is_primary) {
                            $primary_set = true;
                        }
                    }
                }
                
                if (!$primary_set && $i > 0) {
                    $stmt = $conn->prepare("UPDATE property_images SET is_primary = TRUE WHERE property_id = ? LIMIT 1");
                    $stmt->bind_param('i', $property_id);
                    $stmt->execute();
                }
            }
            
            header('Location: /admin/dashboard.php');
            exit;
        } else {
            $error = 'Failed to create property';
        }
    }
}

function validateImage($file) {
    $errors = [];
    
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'errors' => ['File upload failed']];
    }
    
    if ($file['size'] > MAX_IMAGE_SIZE) {
        $errors[] = "File size exceeds " . (MAX_IMAGE_SIZE / 1024 / 1024) . "MB limit";
    }
    
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_ext, ALLOWED_IMAGE_TYPES)) {
        $errors[] = "Invalid file type";
    }
    
    $image_info = getimagesize($file['tmp_name']);
    if (!$image_info) {
        $errors[] = "Unable to read image";
    } else {
        $width = $image_info[0];
        $height = $image_info[1];
        
        if ($width < MIN_IMAGE_WIDTH || $height < MIN_IMAGE_HEIGHT) {
            $errors[] = "Image must be at least " . MIN_IMAGE_WIDTH . "x" . MIN_IMAGE_HEIGHT . "px";
        }
    }
    
    return ['valid' => count($errors) === 0, 'errors' => $errors];
}

function saveImage($file, $property_id) {
    $timestamp = time();
    $random = rand(1000, 9999);
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = "property_{$property_id}_{$timestamp}_{$random}.{$file_ext}";
    
    $filepath = UPLOAD_DIR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false];
    }
    
    $image_url = UPLOAD_URL . $filename;
    return ['success' => true, 'url' => $image_url];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Property - Sukhdham</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/components/navbar.php'; ?>
    
    <div class="max-w-3xl mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Add New Property</h1>
            <a href="/admin/dashboard.php" class="text-blue-600 hover:text-blue-800">← Back to Dashboard</a>
        </div>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" class="bg-white rounded-lg shadow p-6">
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Title *</label>
                <input type="text" name="title" required 
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="Property title">
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Description</label>
                <textarea name="description" rows="4" 
                          class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Property description"></textarea>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Address *</label>
                <input type="text" name="address" required 
                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="Full address">
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Price (₹)</label>
                    <input type="number" name="price" step="0.01" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Enter price">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Area (Sq.ft)</label>
                    <input type="number" name="area_sqft" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Area in sq ft">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Bedrooms</label>
                    <input type="number" name="bedrooms" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Number of bedrooms">
                </div>
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Bathrooms</label>
                    <input type="number" name="bathrooms" min="0"
                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Number of bathrooms">
                </div>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Images (Max 10)</label>
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <input type="file" name="images[]" multiple accept="image/*" 
                           class="w-full"
                           onchange="previewImages(this)">
                    <p class="text-gray-500 text-sm mt-2">Minimum 800x600px, Max 5MB per image</p>
                </div>
                <div id="imagePreview" class="grid grid-cols-4 gap-2 mt-4"></div>
            </div>
            
            <div class="flex gap-4">
                <button type="submit" 
                        class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Create Property
                </button>
                <a href="/public/dashboard.php" 
                   class="bg-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-400">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    
    <script>
        function previewImages(input) {
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = '';
            
            if (input.files) {
                Array.from(input.files).forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const div = document.createElement('div');
                        div.className = 'relative';
                        div.innerHTML = `
                            <img src="${e.target.result}" class="w-full h-24 object-cover rounded-lg">
                            <input type="radio" name="primary_image" value="${index}" ${index === 0 ? 'checked' : ''} class="absolute bottom-1 left-1">
                            <span class="absolute bottom-1 right-1 text-xs bg-white px-1 rounded">${index + 1}</span>
                        `;
                        preview.appendChild(div);
                    };
                    reader.readAsDataURL(file);
                });
            }
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>